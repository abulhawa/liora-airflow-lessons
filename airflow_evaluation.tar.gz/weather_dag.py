import json
import os

import pandas as pd
import pendulum
import requests
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python import PythonOperator
from joblib import dump
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import cross_val_score
from sklearn.tree import DecisionTreeRegressor


def collect_weather():

    cities = Variable.get("cities", deserialize_json=True)
    api_key = Variable.get("openweather_api_key")
    time_now = pendulum.now(tz="Europe/Berlin").format("YYYY-MM-DD HH:mm")

    observations = []

    for city in cities:
        response = requests.get(
            "https://api.openweathermap.org/data/2.5/weather",
            params={"q": city, "appid": api_key},
            timeout=20,
        )

        if not response.ok:
            raise RuntimeError(
                f"Weather request failed for {city}: HTTP {response.status_code}"
            )

        observations.append(response.json())

    with open(f"/app/raw_files/{time_now}.json", "w") as f:
        json.dump(observations, f, indent=2)


def transform_data_into_csv(n_files=None, filename="data.csv"):
    parent_folder = "/app/raw_files"
    files = sorted(os.listdir(parent_folder), reverse=True)

    if n_files:
        files = files[:n_files]

    dfs = []

    for f in files:
        with open(os.path.join(parent_folder, f), "r") as file:
            data_temp = json.load(file)

        for data_city in data_temp:
            dfs.append(
                {
                    "temperature": data_city["main"]["temp"],
                    "city": data_city["name"],
                    "pression": data_city["main"]["pressure"],
                    "date": f.split(".")[0],
                }
            )

    df = pd.DataFrame(dfs)
    print("\n", df.head(10))

    df.to_csv(
        os.path.join("/app/clean_data", filename),
        index=False,
    )


def train_and_save_model(model, X, y, path_to_model="./app/model.pckl"):
    # training the model
    model.fit(X, y)
    # saving model
    print(str(model), "saved at ", path_to_model)
    dump(model, path_to_model)


def prepare_data(path_to_data="/app/clean_data/fulldata.csv"):
    # reading data
    df = pd.read_csv(path_to_data)
    # ordering data according to city and date
    df = df.sort_values(["city", "date"], ascending=True)

    dfs = []

    for c in df["city"].unique():
        df_temp = df[df["city"] == c]

        # creating target
        df_temp.loc[:, "target"] = df_temp["temperature"].shift(1)

        # creating features
        for i in range(1, 10):
            df_temp.loc[:, "temp_m-{}".format(i)] = df_temp["temperature"].shift(-i)

        # deleting null values
        df_temp = df_temp.dropna()

        dfs.append(df_temp)

    # concatenating datasets
    df_final = pd.concat(dfs, axis=0, ignore_index=False)

    # deleting date variable
    df_final = df_final.drop(["date"], axis=1)

    # creating dummies for city variable
    df_final = pd.get_dummies(df_final)

    features = df_final.drop(["target"], axis=1)
    target = df_final["target"]

    return features, target


def compute_model_score(model, X, y):
    cross_validation = cross_val_score(
        model,
        X,
        y,
        cv=3,
        scoring="neg_mean_squared_error",
    )

    model_score = cross_validation.mean()
    return model_score


def evaluate_linear_regression():
    X, y = prepare_data()
    model = LinearRegression()
    score = compute_model_score(model, X, y)
    return score


def evaluate_random_forest():
    X, y = prepare_data()
    model = RandomForestRegressor()
    score = compute_model_score(model, X, y)
    return score


def evaluate_decision_tree():
    X, y = prepare_data()
    model = DecisionTreeRegressor()
    score = compute_model_score(model, X, y)
    return score


def select_best_model(ti):
    scores = {
        "linear_regression": ti.xcom_pull(task_ids="task_evaluate_linear_regression"),
        "decision_tree": ti.xcom_pull(task_ids="task_evaluate_decision_tree"),
        "random_forest": ti.xcom_pull(task_ids="task_evaluate_random_forest"),
    }

    best_name = max(scores, key=scores.get)

    models = {
        "linear_regression": LinearRegression(),
        "decision_tree": DecisionTreeRegressor(),
        "random_forest": RandomForestRegressor(),
    }

    print(f"Scores: {scores}")
    print(f"Selected model: {best_name}")

    X, y = prepare_data()

    train_and_save_model(
        models[best_name],
        X,
        y,
        path_to_model="/app/clean_data/best_model.pickle",
    )


with DAG(
    dag_id="weather_collect",
    start_date=pendulum.datetime(2026, 10, 29, tz="UTC"),
    schedule="* * * * *",
    catchup=False,
    max_active_runs=1,
    tags=["airflow eval", "ali"],
):
    task_collect = PythonOperator(
        task_id="data_collection",
        python_callable=collect_weather,
    )

    task_transform_recent = PythonOperator(
        task_id="task_transform_recent",
        python_callable=transform_data_into_csv,
        op_kwargs={
            "n_files": 20,
            "filename": "data.csv",
        },
    )

    task_transform_all = PythonOperator(
        task_id="task_transform_all",
        python_callable=transform_data_into_csv,
        op_kwargs={
            "filename": "fulldata.csv",
        },
    )

    task_evaluate_linear_regression = PythonOperator(
        task_id="task_evaluate_linear_regression",
        python_callable=evaluate_linear_regression,
    )

    task_evaluate_random_forest = PythonOperator(
        task_id="task_evaluate_random_forest",
        python_callable=evaluate_random_forest,
    )

    task_evaluate_decision_tree = PythonOperator(
        task_id="task_evaluate_decision_tree",
        python_callable=evaluate_decision_tree,
    )

    task_select_best_model = PythonOperator(
        task_id="task_select_best_model",
        python_callable=select_best_model,
    )

    task_collect >> [task_transform_all, task_transform_recent]
    (
        task_transform_all
        >> [
            task_evaluate_linear_regression,
            task_evaluate_random_forest,
            task_evaluate_decision_tree,
        ]
        >> task_select_best_model
    )
